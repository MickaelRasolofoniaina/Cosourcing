import { useNavigate, useParams } from "react-router-dom";
import { BaseEcran } from "../../shared/components/BaseEcran";
import { Etablissement } from "../../../models/entite/Etablissement";
import { ajouterEtablissement } from "../services/EtablissementService";
import { EtablissementRoute } from "../EtablissementRouter";
import { FormulaireEtablissement } from "./FormulaireEtablissement";
import { useState } from "react";

export const AjoutEtablissement : React.FC = () =>{	
	
	const params = useParams();
	const idEtablissement = parseInt(params.idEtablissement ?? "0");
	const idSociete = parseInt(params.idSociete ?? "0")
	
	const navigate = useNavigate();

  const [erreur, setErreur ] = useState(false);
 

	const executer = (etablissement : Etablissement) => {
		etablissement.id = idEtablissement;
    setErreur(false);
    console.log("ajouter etablissement")
    ajouterEtablissement(etablissement)
      .then((response) => {
        if (response > 0) {
          navigate(`${EtablissementRoute.Root}?idSociete=${idSociete}`);
        }
      })
      .catch(() => {
        setErreur(true);
      })
      .finally(() => {
        console.log("ajout avec succes");
      });
	}
	return(
		<BaseEcran titre="Modifier Etablissement">
			<FormulaireEtablissement executable={executer} idEtablissement={idEtablissement} idSociete={idSociete} />
    </BaseEcran>
	)
}